
const { Client, LocalAuth } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");
const fs = require("fs-extra");

fs.ensureDirSync("./data");

const files = {
 roles:"./data/roles.json",
 warnings:"./data/warnings.json",
 mute:"./data/mute.json",
 spam:"./data/spam.json",
 levels:"./data/levels.json",
 games:"./data/games.json",
 votes:"./data/votes.json"
};

for (let k in files) {
 if (!fs.existsSync(files[k])) fs.writeJsonSync(files[k], {});
}

let config = fs.readJsonSync("./config.json");
let roles = fs.readJsonSync(files.roles);
let warnings = fs.readJsonSync(files.warnings);
let mute = fs.readJsonSync(files.mute);
let spam = fs.readJsonSync(files.spam);
let levels = fs.readJsonSync(files.levels);
let games = fs.readJsonSync(files.games);
let votes = fs.readJsonSync(files.votes);

// ---------------- ROLE SYSTEM ----------------
function role(u){ return roles[u] || "user"; }

function lvl(r){
 return {user:0, mod:1, admin:2, "co-owner":3, owner:4}[r] || 0;
}

function has(u, need){
 return lvl(role(u)) >= lvl(need);
}

function isOwner(u){
 return role(u) === "owner";
}

function can(actor, target){
 const a = role(actor);
 const t = role(target);
 if (t === "owner") return false;
 if (t === "co-owner" && !isOwner(actor)) return false;
 return lvl(a) > lvl(t);
}

// ---------------- NORMALIZE ----------------
function norm(t){
 return t.toLowerCase()
 .replace(/0/g,"o").replace(/1/g,"i")
 .replace(/3/g,"e").replace(/4/g,"a")
 .replace(/5/g,"s").replace(/[\s_\-*\.]/g,"");
}

const badwords = ["kokot","piča","curak","zmrd","jebat"];

let xpCD = {};

function xp(u, chat){
 if (!levels[u]) levels[u] = {xp:0, level:1};
 if (!xpCD[u] || Date.now()-xpCD[u] > 60000){
  xpCD[u] = Date.now();
  levels[u].xp += config.xpPerMessage;

  if (levels[u].xp >= levels[u].level * 100){
    levels[u].xp = 0;
    levels[u].level++;
    chat.sendMessage("⭐ LEVEL UP " + levels[u].level);
  }
 }
}

// ---------------- BOT ----------------
const client = new Client({
 authStrategy: new LocalAuth(),
 puppeteer: { headless: true }
});

client.on("qr", qr => qrcode.generate(qr, { small: true }));
client.on("ready", () => console.log("BOT ONLINE"));

// ---------------- MESSAGE ----------------
client.on("message", async m => {

 const chat = await m.getChat();
 if (!chat.isGroup) return;

 const u = m.author || m.from;
 const txt = norm(m.body);

 xp(u, chat);

 // spam
 if (!spam[u]) spam[u] = [];
 spam[u].push(Date.now());
 spam[u] = spam[u].filter(t => Date.now() - t < config.spamTime);

 if (spam[u].length > config.spamLimit && !isOwner(u)){
  await m.delete(true);
  return chat.sendMessage("⚠️ spam");
 }

 // badwords
 for (let w of badwords){
  if (txt.includes(norm(w)) && !isOwner(u)){
   warnings[u] = (warnings[u] || 0) + 1;
   await m.delete(true);

   if (warnings[u] >= config.maxWarnings){
    mute[u] = Date.now() + config.muteTime;
    chat.sendMessage("🔇 mute");
   } else chat.sendMessage("⚠️ vulgarizmus");

   return;
  }
 }

 if (txt.includes("bober")) return m.reply("🦫 super kamarát");

 if (!m.body.startsWith(config.prefix)) return;

 const args = m.body.slice(1).split(" ");
 const cmd = args.shift().toLowerCase();

 // ROLE
 if (cmd === "role") return m.reply(role(u));

 // GROUPS
 if (cmd === "groups"){
  const chats = await client.getChats();
  const g = chats.filter(c => c.isGroup);
  return m.reply(g.map(x => x.name + " | " + x.id._serialized).join("\n"));
 }

 // PROMOTE
 if (cmd === "promote"){
  if (!has(u,"admin")) return;
  const t = m.mentionedIds[0];
  if (!can(u,t)) return;
  roles[t] = "admin";
  chat.promoteParticipants([t]);
 }

 // DEMOTE
 if (cmd === "demote"){
  if (!has(u,"admin")) return;
  const t = m.mentionedIds[0];
  if (!can(u,t)) return;
  roles[t] = "user";
  chat.demoteParticipants([t]);
 }

 // ---------------- VOTE ----------------
 if (cmd === "vote"){
  const target = m.mentionedIds[0];
  if (!target) return;

  if (votes[chat.id._serialized])
   return m.reply("vote running");

  votes[chat.id._serialized] = {
   target,
   yes: new Map(),
   no: new Map(),
   expires: Date.now() + 60000
  };

  chat.sendMessage("🗳️ VOTE START 👍 👎");
 }

});

// ---------------- REACTIONS (1 user = 1 vote) ----------------
client.on("message_reaction", r => {

 const id = r.message.id.remote;
 const v = votes[id];
 if (!v) return;

 const user = r.senderId;
 const em = r.reaction;

 if (v.yes.has(user) || v.no.has(user)){
  v.yes.delete(user);
  v.no.delete(user);
 }

 if (em === "👍") v.yes.set(user, true);
 if (em === "👎") v.no.set(user, true);
});

// ---------------- VOTE ENGINE ----------------
setInterval(async () => {

 for (let id in votes){

  let v = votes[id];
  if (Date.now() < v.expires) continue;

  const chat = await client.getChatById(id);

  const yes = v.yes.size;
  const no = v.no.size;

  if (yes > no){
   chat.sendMessage("⚖️ APPROVED");
  } else {
   chat.sendMessage("❌ REJECTED");
  }

  delete votes[id];
 }

}, 5000);

client.initialize();
